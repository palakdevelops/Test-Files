# Source list: every factual claim in the script

Legend: **T** = tested by us, evidence in the log (file 03) and raw files. **S** = sourced. **O** = opinion/advice, not a factual claim. **D** = definition by us.

| Script sec | Claim | Type | Evidence |
|---|---|---|---|
| S1 | 5 meetings, 24 tasks | T | `test/key/KEY.md` (24 = 5+5+5+4+5) |
| S1 | One prompt found all 24, the other missed one | T | Log section C |
| S2 | Small-business owners hold meetings and tasks get lost | O | Framing, not a statistic. No number is claimed |
| S2 | YouTube autocomplete for "AI meeting notes" suggested "taker", "app", "free" | T | `research/autocomplete_raw.txt`, fetched 2026-11-20 from suggestqueries.google.com (YouTube mode `ds=yt`) |
| S2 | Google suggested similar things | T | same file, non-YouTube mode |
| S2 | Autocomplete is not a perfect measure | O | Method limit, stated by us |
| S3 | 5 fake meetings, trades listed, about 170 words each | T | `test/inputs/T1-T5.txt` (160-180 words, `wc -w`) |
| S3 | 24 real tasks, 11 traps | T/D | KEY.md; "real task" definition is ours |
| S3 | Quoted trap lines | T | T1 and T3 transcript text, verbatim (the Sunday and oven lines are from T1; the template line is T3) |
| S4 | Prompt A wording; prompt B wording | T | Raw files |
| S4 | Tool was Claude, Haiku tier; fresh chat per meeting; one try each | T | Log section B. Exact model version string unknown |
| S4 | "Smaller, cheaper model" | S (soft) | Anthropic names its small model tier "Haiku"; confirm on the Anthropic model page. Founder may confirm on anthropic.com model page before recording. Not stated as a price figure |
| S5 | Key written before runs, hashed | T | `test/key_sha256.txt` (hash 06eb69fc..., 2026-11-20T11:48:46Z), re-verified after runs |
| S5 | Scoring rules | D | KEY.md "Scoring" |
| S5 | Scored by us, not a program | T | Log section C |
| S6 | 24/24 found, owners, deadlines right, 0 false | T | Log C, prompt A table |
| S6 | Bakery "Not decided"; print shop printer under "open issue", Aisha calls vendor only if it persists | T | raw_prompt_A T1, T5 |
| S6 | Plumbing van items sit in the same list | T | raw_prompt_A T2 |
| S7 | 23/24 found, 1 missed, 1 owner wrong, 0 false | T | Log C, prompt B table |
| S7 | Missed: Greg tells Ben to follow up the church flyer quote on Friday if no answer | T | T5 transcript lines 7-9; absent from raw_prompt_B T5 |
| S7 | Calendar: "Ben and Aisha", Greg left out | T | T5 last lines; raw_prompt_B T5 |
| S7 | Possible cause: the word "conditional" | O | Hypothesis, said to be a guess and untested |
| S7 | Clean table, same shape every row | T | raw_prompt_B |
| S8 | Limits (5 meetings, 1 run, 1 model, typed text) | T | Method |
| S8 | 24 vs 23 could be luck; result could flip | O | Statistical caution, not tested |
| S8 | Real meetings have noise and crosstalk | O | General knowledge |
| S8 | Main risk is missing tasks | O | Conclusion from one observed miss; flagged as what "we can say" on these five meetings only |
| S9 | Check "if" and "everybody" lines; use a table | O | Advice drawn from the observed misses |
| S9 | Do not paste private customer details before reading privacy terms | O | General precaution; not a legal claim. No data-protection law is cited |

No external statistics, competitor claims, product price claims or named third-party company claims are used in the script. The only third-party named is Claude/Anthropic (the tool tested, described only by what we observed). Not sponsored; no affiliate links; say so if that changes.

Open for human check before publish: (1) the one soft "Haiku is a smaller model" statement; (2) the trademark check of "Ran It First" (PAL-3 gate, not done); (3) the manual YouTube competition check (PAL-2 gap).
