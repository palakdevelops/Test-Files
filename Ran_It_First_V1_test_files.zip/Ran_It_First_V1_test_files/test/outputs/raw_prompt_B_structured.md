# RAW outputs, Prompt B (structured extraction prompt), verbatim, run 2026-11-20
Prompt B text: "You extract action items from meeting transcripts for a small business. List only real commitments or assignments, where a named person will do something. For each, give: Owner, Task, Deadline (exactly as said in the meeting; write "none stated" if no deadline was given). Do NOT list ideas that are undecided, things already done, things decided against, or conditional maybes. Do not invent anything that is not in the transcript."
Tool: Claude via Claude Code subagent, model setting "haiku". One fresh session per transcript, one run each, no retries.

## T1
| Owner | Task | Deadline |
|---|---|---|
| Priya | Get two quotes from other suppliers for flour (she already has one from Millbrook, so she needs a second) | Before next Wednesday |
| Marcus | Call the provider about the card reader that keeps dropping out and ask for a replacement | Today |
| Marcus | Take a photo of the peeling window sign and send it to the sign guy | Probably this week (Dana: "No rush") |
| Priya | Send Dana the new sourdough recipe | Friday |
| Dana | Update the allergen chart once Priya sends the new sourdough recipe | None stated |

## T2
| Owner | Task | Deadline |
|---|---|---|
| Joy | Send Sam her availability for next week (she may be at the supplier Wednesday morning) | by end of day Thursday |
| Luis | Check the shelf for 15 mm elbows and compression joints, then order any that are missing (not the ones already in stock) | Check tonight, order tomorrow; restock before Monday's jobs |
| Sam | Email Mr Patel about the overdue invoice | today |
| Joy | Visit the Elm Street customer for the bathroom quote | visit Saturday; quote by Tuesday |

## T3
| Owner | Task | Deadline |
|---|---|---|
| Tom | Send the drafted client reminder email to Elena for approval | tomorrow morning |
| Rhea | Get two quotes for the scanner repair and book the cheaper one | none stated |
| Tom | Call the Garcia family to tell them their documents are incomplete | none stated |
| Rhea | Send Tom the Garcia family's contact number | after this call |
| Elena | Raise the seasonal temp hire idea at the partner meeting (the hire itself is not yet decided) | Monday's partner meeting |

## T4
| Owner | Task | Deadline |
|---|---|---|
| Beth | Draft a promo for the newsletter and have it ready | for the first of next month |
| Beth | Find her notes from last year's comparison of the booking site and two other tools, and send them to Mei | probably Monday |
| Carlos | Look at whether a beginner series is realistic and report back to Mei | at the next meeting |
| Mei | Call the landlord back about the lease renewal | this week |

## T5
| Owner | Task | Deadline |
|---|---|---|
| Ben | Confirm the paper arrival date with the supplier and tell Aisha | tomorrow |
| Greg | Renew the insurance policy | next week |
| Aisha | Order two new cutting blades (up to $80) | today |
| Ben and Aisha | Update the shared job calendar | none stated |
