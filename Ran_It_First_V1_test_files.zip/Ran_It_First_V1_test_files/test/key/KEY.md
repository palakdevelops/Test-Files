# ANSWER KEY (written BEFORE any AI run; not shown to the AI under test)

Rule: an item counts when a named person commits or is clearly assigned to do something. Not counted (traps): undecided ideas, conditional "let's see first", things already done, things decided against, and discussion topics.
Format: owner | task | deadline as stated.

## T1 (5 items; 2 traps)
1. Priya | get a second supplier quote (Millbrook is the first) | before next Wednesday
2. Marcus | call card-reader provider, ask for a replacement | today
3. Marcus | photo of peeling window sign, send to sign guy | this week (probably)
4. Priya | send new sourdough recipe to Dana | Friday
5. Dana | update allergen chart | after she gets the recipe
Traps: Sunday opening (undecided, revisit next month); oven service on the 3rd (already booked and confirmed).

## T2 (5 items; 2 traps)
1. Joy | send availability to Sam | end of day Thursday
2. Luis | check shelf stock, then order missing fittings (15mm elbows, compression joints) | check tonight, order tomorrow
3. Sam | email Mr Patel about overdue invoice | today
4. Joy | visit Elm Street for bathroom quote | Saturday
5. Joy | send Elm Street quote | Tuesday
Traps: van already fixed; second van (not this quarter).

## T3 (5 items; 2 traps)
1. Tom | send client reminder email draft to Elena for approval | tomorrow morning
2. Rhea | get two prices, book scanner repair | none stated
3. Tom | call Garcia family about incomplete documents | none stated
4. Rhea | send Garcia number to Tom | after the call
5. Elena | raise seasonal temp hire at partner meeting | Monday
Traps: engagement-letter template (decided to skip); "goes out Friday" is an event, not a separate task.

## T4 (4 items; 3 traps)
1. Beth | draft newsletter promo | ready by the 1st of next month
2. Carlos | assess whether a beginner series is realistic, tell Mei | next meeting
3. Beth | find last year's booking-tool comparison notes, send to Mei | Monday (probably)
4. Mei | call landlord back about lease renewal | this week
Traps: mats (already ordered, arrive Thursday, nothing needed); logo change (rejected); "talk about lease next time" (discussion only).

## T5 (5 items; 2 traps)
1. Ben | confirm paper arrival date with supplier and tell Aisha | tomorrow
2. Ben | follow up on church flyer quote if no reply | Friday
3. Greg | renew insurance policy | next week
4. Aisha | order two cutting blades, up to $80 | today
5. Greg, Ben, Aisha (everybody) | update the shared job calendar | none stated
Traps: printer vendor call (conditional, "let's see first"); Wilson order itself (conditional on paper, no one assigned beyond item 1).

## Totals
Real items: 5+5+5+4+5 = 24. Traps: 2+2+2+3+2 = 11.

## Scoring (applied identically to both prompts)
- Found: output contains the item (owner and task recognisable). Missed otherwise.
- Wrong owner: item found but attributed to the wrong person (or "unassigned" when an owner was clear).
- Wrong deadline: item found but deadline missing or different from the stated one (a stated "none" is correct when no deadline is given; inventing a deadline is wrong).
- Invented/false item: listed as an action item but is a trap or not in the transcript.
- Metrics: recall = found/24; false items counted separately; fully correct item = found + right owner + right deadline.
