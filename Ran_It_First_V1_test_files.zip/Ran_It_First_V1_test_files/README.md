# Ran It First - Video 1 test files
"AI Meeting Notes: 5-Word Prompt vs Careful Prompt"

What this is: the exact material behind the video. 5 invented small-business meeting transcripts (test/inputs), the two prompts, the answer key written BEFORE any run (test/key), every raw output (test/outputs), checksums, and the scoring log with step-by-step instructions to repeat the test (03_test_steps_and_results_log.md).

Read this first:
- All meetings, people, shops and numbers are INVENTED. No real data.
- Small test: 5 meetings, 10 runs, one try each, one model (Claude, Haiku tier), scored by one rater. Results are not proof that either prompt is better and are not guarantees. Your results will differ.
- Not professional advice. Not sponsored. No affiliate links.
- Claude is a trademark of its owner. We are not affiliated with or endorsed by Anthropic, Google or YouTube.
- Script, visuals and edits were prepared with AI assistance and reviewed by a human; the voice-over is a real person's.

Reuse: you may copy, share and adapt these files with credit to "Ran It First" (Creative Commons Attribution 4.0, CC BY 4.0, https://creativecommons.org/licenses/by/4.0/). The founder may change this licence line before publishing.

Files:
- 03_test_steps_and_results_log.md  how to repeat + scores
- 04_sources_claims.md  where each claim comes from
- test/inputs/T1-T5.txt  the 5 invented transcripts
- test/key/KEY.md  answer key (24 tasks, 11 traps) + test/key_sha256.txt
- test/outputs/raw_prompt_A_summarize.md, raw_prompt_B_structured.md  verbatim outputs (Prompt B text at the top)
- test/sha256_inputs_outputs.txt  checksums
- research/autocomplete_raw.txt  the autocomplete check (Google/YouTube suggestions, 20 Nov 2026)
