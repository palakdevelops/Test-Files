# Test steps and raw results log

## A. Test steps (anyone can repeat this with a free AI chat)
1. Open a new chat in your AI tool. Paste prompt A, then the contents of `test/inputs/T1.txt`. Prompt A is exactly: `Summarize this meeting.`
2. Copy the full answer into a text file. Do not edit. Close the chat.
3. Repeat steps 1-2 in a NEW chat for T2, T3, T4, T5. One try each. No retries.
4. Repeat steps 1-3 with prompt B (full text is at the top of `test/outputs/raw_prompt_B_structured.md`).
5. Score each output against `test/key/KEY.md` using the rules in the key: found / right owner / right deadline / false task.
6. Add up: tasks found out of 24, fully correct out of 24, false tasks.
Optional on-screen version for the founder: do steps 1-3 for ONE meeting (T5) in OBS with any free AI tool, and say clearly it is a re-run and that wording can differ. Do not replace the logged numbers in the script with live numbers unless you re-score all ten.

## B. What was actually run (2026-11-20, UTC about 11:48-11:55)
- Tool under test: Claude (Anthropic) through a Claude Code subagent with model setting "haiku" (Haiku tier; the exact version string was not shown to the agent). Subscription tool, no API key, no extra cost.
- 5 original transcripts written by the research agent (160-180 words each), 10 runs (5 meetings x 2 prompts), each in a fresh session that read only its own transcript file; the answer key was moved out of the workspace during the runs and restored afterwards (SHA-256 identical before and after: `06eb69fcc986866fa3d57ba56f1391ec7fb3fb65f9fd8f18093f405495f6aaca`, recorded before any run in `test/key_sha256.txt`).
- Answer key written before any run: 24 real tasks, 11 traps. File: `test/key/KEY.md`.
- Raw outputs, verbatim: `test/outputs/raw_prompt_A_summarize.md`, `test/outputs/raw_prompt_B_structured.md`. Checksums of inputs/outputs: `test/sha256_inputs_outputs.txt`.

## C. Scoring (by the research agent, applying the key; a human can re-score from the raw files)
Per item: F = found, O = owner right, D = deadline right (a condition like "once the recipe arrives" counts when it appears anywhere in the item).

### Prompt A ("Summarize this meeting.")
| Meeting | Key tasks | Found | Owner right | Deadline right | False tasks | Note |
|---|---|---|---|---|---|---|
| T1 bakery | 5 | 5 | 5 | 5 | 0 | "Sunday opening" listed as "Not decided"; oven listed as done |
| T2 plumbing | 5 | 5 | 5 | 5 | 0 | Visit + quote both captured; van items listed but as facts |
| T3 accounting | 5 | 5 | 5 | 5 | 0 | Template listed under "Decisions: no new template" |
| T4 yoga | 4 | 4 | 4 | 4 | 0 | Mats "No action needed"; logo "No, not this year" |
| T5 print | 5 | 5 | 5 | 5 | 0 | Printer under "Open issue", conditional kept as conditional |
| **Total** | **24** | **24** | **24** | **24** | **0** | Fully correct 24/24 |

### Prompt B (structured extraction prompt)
| Meeting | Key tasks | Found | Owner right | Deadline right | False tasks | Note |
|---|---|---|---|---|---|---|
| T1 | 5 | 5 | 5 | 5 | 0 | Dana's deadline column says "None stated" but the condition "once Priya sends the recipe" is in the Task column; counted correct |
| T2 | 5 | 5 | 5 | 5 | 0 | Visit and quote merged into one row; both captured |
| T3 | 5 | 5 | 5 | 5 | 0 | |
| T4 | 4 | 4 | 4 | 4 | 0 | |
| T5 | 5 | 4 | 3 | 4 | 0 | **Missed:** Ben to follow up church flyer quote on Friday if no reply. **Wrong owner:** calendar assigned to "Ben and Aisha", Greg omitted. |
| **Total** | **24** | **23** | **22** | **23** | **0** | Fully correct 22/24 |

Neither prompt listed any of the 11 traps as a task. Format: prompt B returned a table with identical columns every time; prompt A returned prose bullets mixing tasks with non-tasks.

## D. Honest limits (also in the script, S8)
- 5 synthetic, tidy typed meetings; real transcripts have errors and crosstalk. 1 run per cell, so 24 vs 23 may be noise. 1 model. Scored by the agent that wrote the key (risk of bias; mitigated by writing the key first, hashing it, and publishing all raw files).
- The explanation for the miss (word "conditional" in prompt B) is a guess and was not tested. The key itself could be argued on item T5-2 (a conditional follow-up); we count it a real task because Greg assigned it to Ben by name with a date.
- Not tested: different models, longer meetings, audio transcription, privacy tooling.

## E. Demand evidence (free autocomplete, fetched 2026-11-20 from suggestqueries.google.com, raw in `research/autocomplete_raw.txt`)
- YouTube autocomplete for "ai meeting notes": "ai meeting notes taker", "ai meeting notes app", "ai meeting notes free", "ai meeting notes in notion", "ai meeting notes microsoft teams". For "chatgpt meeting summary": "chatgpt meeting minutes", "chatgpt meeting transcript summary".
- Google autocomplete: "ai meeting notes free", "ai meeting notes taker", "ai meeting notes generator", "ai meeting notes and action items", "chatgpt meeting summary prompt", "chatgpt meeting minutes template".
- Comparison candidates had thinner autocomplete: "ai invoice follow up" returned no YouTube suggestions; "automate weekly report from spreadsheet" returned none on either; "ai email triage" 1 YouTube suggestion. So meeting notes was the strongest of those checked.
- Limits: autocomplete is a signal that people search, not a volume count. Google Trends and keyword tools were not available to this agent. Manual 30-minute YouTube competition check (the open item in PAL-2/PAL-5) still needs a human; it was not done.
